package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private NotificationManager manager;
    private Notification notification;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
//        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
//            NotificationChannel channel = new NotificationChannel("leo", "测试通知", NotificationManager.IMPORTANCE_HIGH);
//            manager.createNotificationChannel(channel);
//        }
//        notification= new NotificationCompat.Builder(this,"leo")
//                .setContentTitle("qq通知")
//                .setContentText("密码错误")
//                .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.pic1))
//                .setColor(Color.parseColor("#ff0000"))
//                .setAutoCancel(true)//设置自动取消
//                .build();
//    }
//    public void sendNotification(View view){
////        触发条件，发送请求
//        manager.notify(1,notification);
        Button button=findViewById(R.id.button2);
        EditText edittex = findViewById(R.id.editTextTextPassword2);
        edittex.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Toast.makeText(MainActivity.this,"手机格式不对！",Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String string=edittex.getText().toString();
                if (string.length()==11){
                    Toast.makeText(MainActivity.this,"登录成功！",Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(MainActivity.this,"密码不对！",Toast.LENGTH_SHORT).show();
                }
            }
        });
}
}