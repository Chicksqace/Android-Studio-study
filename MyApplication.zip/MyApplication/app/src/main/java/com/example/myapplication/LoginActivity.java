package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    //定义dbhelper变量
    private DbHelper dbHelper;
    //登录按钮
    private Button loginButton;
    //请输入用户名
    private EditText usernameEditText;
    //请输入密码
    private EditText passwordEditText;
    //记住密码
    private CheckBox rememberCheckbox;
    //注册按钮
    private TextView regirstrationButton;

    //定义shareperference
    private SharedPreferences sp;
    //editor用于填充数据
    private SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //dbhelper 实例化
        dbHelper = new DbHelper(this);
        //将layout中的控件与java中的类对象进行绑定
        usernameEditText = (EditText) findViewById(R.id.username);
        passwordEditText = (EditText) findViewById(R.id.password);
        regirstrationButton = (TextView) findViewById(R.id.registrationButton);
        loginButton = (Button) findViewById(R.id.loginButton);
        rememberCheckbox = (CheckBox) findViewById(R.id.rememberPasswordCheckbox);

        //监听注册按钮的点击
        regirstrationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,RegActivity.class);
                startActivity(intent);
            }
        });
//        regirstrationButton.setOnClickListener(v -> {
//            //新建一个Intent
//            Intent intent = new Intent(LoginActivity.this, RegActivity.class);
//            //将用户名和密码发送给注册窗口
//            intent.putExtra("username",usernameEditText.getText().toString());
//            intent.putExtra("password",passwordEditText.getText().toString());
//            //打开一个新窗口
//            startActivity(intent);
//            //登录页面销毁掉
//            LoginActivity.this.finish();
//        });

        Intent intent = getIntent();
        //提取出intent中的数据
        String username= intent.getStringExtra("username");
        final String password=  intent.getStringExtra("password");
        //将注册页面中的传递过来的Intent数据提取出来
        //然后设置对应的登录页面中的用户名和密码输入框中的text属性
        usernameEditText.setText(username);
        passwordEditText.setText(password);


        //初始化sharepreferences
        sp = this.getSharedPreferences("Login",MODE_PRIVATE);
        editor = sp.edit();
        //将sharepreferences中得数据提取出来存放到editext中，并且
        //修改rememberCheckBox得勾选状态
        usernameEditText.setText(sp.getString("username",""));
        passwordEditText.setText(sp.getString("password",""));
        rememberCheckbox.setChecked(sp.getBoolean("isRemPass",false));


        //登录跳转
        loginButton.setOnClickListener(v -> {
            //需要校验账号和密码是否正确
            boolean exist = dbHelper.selectUser(usernameEditText.getText().toString(), passwordEditText.getText().toString());
            if(exist){
                if (rememberCheckbox.isChecked()){
                    //记住密码是勾选状态
                    editor.putString("username",usernameEditText.getText().toString());
                    editor.putString("password",passwordEditText.getText().toString());
                    editor.putBoolean("isRemPass",true);
                    //确认提交修改
                    editor.commit();
                }else{
                    //记住密码不是勾选状态
                    editor.putString("username","");
                    editor.putString("password","");
                    editor.putBoolean("isRemPass",false);
                    //确认提交修改
                    editor.commit();
                }
                Toast.makeText(LoginActivity.this,"登录成功！",Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent1);
            }else{
                Toast.makeText(LoginActivity.this,"登录失败！",Toast.LENGTH_SHORT).show();
                //注册失败后需要清空用户输入框和密码输入框
                usernameEditText.setText("");
                passwordEditText.setText("");
                //使得焦点重新停在用户名输入框上。
                usernameEditText.requestFocus();
            }

        });
    }
}
