package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button=findViewById(R.id.button2);
        EditText edittex = findViewById(R.id.editTextTextPassword2);
        edittex.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Toast.makeText(MainActivity.this,"手机格式不对！",Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String string=edittex.getText().toString();
                if (string.length()==11){
                    Toast.makeText(MainActivity.this,"格式检测正确！",Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(MainActivity.this,"手机格式不对！",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}